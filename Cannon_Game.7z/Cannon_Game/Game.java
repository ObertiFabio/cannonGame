


//import javax.swing.*;

import java.awt.Canvas;
import java.awt.Dimension;
import javax.swing.JFrame;
import java.awt.image.BufferedImage;
import java.awt.image.BufferStrategy;
import java.awt.Graphics;
import java.awt.event.*;
//import javafx.scene.input.*;



public class Game extends Canvas implements ComponentListener, Runnable, KeyListener
{
    //attributi finestra
    private static final int width=1280;
    private static final int height=720;
    private static final String title="CANNON GAME";
    //inizializzazione immagini
    private BufferedImage img_sfondo=null;
    private BufferedImage img_cannone=null;
    private BufferedImage img_aereo=null;
    private BufferedImage img_bomba=null;
    //inizializzazione oggetto cannone
    private Cannone obj_cannone;
    //variabile per far finire il gioco
    private boolean giocoAttivo=false;
    //inizializzazione bomba prova
    private Bomba obj_bomba;
    
    //costruttore
    
    public Game(){
        loadResources();    //carica risorse
        iniziaGioco();      //richiama funzione per creare cannone
    }
    
    //metodo main per far partire il gioco
    
    public static void main(String[] args) {
        Game game=new Game();
        //set delle varie grandezze del gioco
        game.setPreferredSize(new Dimension(width, height));
        game.setMaximumSize(new Dimension(width, height));
        game.setMinimumSize(new Dimension(width, height));
        //creazione della finestra
        JFrame frame = new JFrame(game.title);  
        //varie impostazioni della finestra
        frame.add(game);
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        //aggiunti di listener
        frame.addKeyListener(game);
        frame.addComponentListener(game);
        //creazione gioco come thread
        Thread gioco = new Thread(game);
        //fa iniziare il gioco
        gioco.start();
        
    }
    
    //metodi
    
    //override Runnable
    //il gioco inizia
    public void run(){
        giocoAttivo=true;
        while(giocoAttivo){
            draw();
        }
    }
    
    //disegna lo sfondo
    private void draw(){
        BufferStrategy buffer = this.getBufferStrategy();
        if(buffer==null){
            createBufferStrategy(2);
            return;
        }
        //"trasforma" lo sfondo in un canvas permettendo di mostare testi,
        //immagini, forme ecc. in maniera indipendente dal resto
        Graphics g = buffer.getDrawGraphics();
        //disegna lo sfondo
        g.drawImage(img_sfondo,0,0,width,height,this);
        //disegna il cannone
        obj_cannone.disegna(g);
        //===============================
        //disegna la bomba
        obj_bomba.disegna(g);
        //===============================
        //lo rende visibile
        g.dispose();
        buffer.show();
    }
    
    //carica le immagini e le assegna a delle variabili 
    //es: sfondo ora è uguale a sfondo.png
    private void loadResources(){
        CaricatoreImmagini loader = new CaricatoreImmagini();
        img_sfondo = loader.caricaImmagine("immagini/prova.png");
        img_cannone=loader.caricaImmagine("immagini/cannoneVero.png");
        img_bomba=loader.caricaImmagine("immagini/bomba.png");
        System.out.println("risorse caricate");
    }
    
    //fa iniziare anche il cannone
    //richiama la funzione run del cannone
    private void iniziaGioco(){
        obj_cannone=new Cannone(img_cannone,375,400,-100,450);
        //obj_cannone.start();
        obj_bomba = new Bomba(img_bomba,500,500,obj_cannone.getX(),315);
        System.out.println("larghezza finestra: "+width);
        System.out.println("altezza finestra: "+height);
        //System.out.println("y cannonao: "+obj_cannone.getY());
    }
    
    //override KeyListener
    //fa muovere il cannone con le frecce (left, right)
    public void keyPressed(java.awt.event.KeyEvent e){
        char direction;
        if(e.getKeyCode()==KeyEvent.VK_RIGHT){
            obj_cannone.aggiorna('r', width);
        }
        else if(e.getKeyCode()==KeyEvent.VK_LEFT){
            obj_cannone.aggiorna('l', width);
        }
        if(e.getKeyCode()==KeyEvent.VK_SPACE){
            //bombe[numeroBombe].start();
            obj_bomba.aggiorna(obj_cannone.getX());
            obj_bomba.start();
            //numeroBombe++;
        }
    }
    //override KeyListener
    public void keyTyped(java.awt.event.KeyEvent e){
    }
    //override KeyListener
    public void keyReleased(java.awt.event.KeyEvent e){
    }
    
    //override
    public void componentResized(ComponentEvent e){}        
    //override
    public void componentMoved(ComponentEvent e){}
    //override
    public void componentShown(ComponentEvent e){}
    //override
    public void componentHidden(ComponentEvent e){}
}
