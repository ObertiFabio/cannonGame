import java.awt.image.BufferedImage;
import java.awt.Graphics;

public class Cannone extends Thread
{
    //attributi cannone
    private int larghezza;
    private int altezza;
    private boolean attivo;
    private int x;
    private int y;
    BufferedImage img_cannone;
    
    //costruttore
    public Cannone(BufferedImage image,int larghezza,int altezza,int x, int y){
        this.larghezza=larghezza;
        this.altezza=altezza;
        this.x=x;
        this.y=y;
        this.img_cannone=image;
        attivo=true;
    }
    
    //override Thread
    public void run(){
        /*attivo=true;
        while(attivo){
            aggiorna();
            try
            {
                sleep(50);
            }
            catch (InterruptedException ie)
            {
                ie.printStackTrace();
            }
        }*/
    }
    
    //muove il cannone
    public void aggiorna(char direction, int width){
        if(direction=='r'){
            if(x+10<1100)
                x+=10;   
        }
        else{
            if(x-10>=-100)
                x-=10;
        }
        System.out.println("x cannonao: "+x);
    }
    
    //si disegna
    public void disegna(Graphics g){
        g.drawImage(img_cannone,x,y,larghezza,altezza,null);
    }
    
    //restituisce la posizione x
    public int getX(){
        return x;
    }
    
    //restituisce la posizione y
    public int getY(){
        return y;
    }
}
