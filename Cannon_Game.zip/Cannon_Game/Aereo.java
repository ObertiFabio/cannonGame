import java.awt.image.BufferedImage;
import java.awt.Graphics;

public class Aereo extends Thread
{
    //attributi cannone
    private int larghezza;
    private int altezza;
    private boolean attivo;
    private int x;
    private int y;
    BufferedImage img_aereo;
    
    //costruttore
    public Aereo(BufferedImage image,int larghezza,int altezza,int x, int y){
        this.larghezza=larghezza;
        this.altezza=altezza;
        this.x=x;
        this.y=y;
        img_aereo=image;
        attivo=false;
    }
    
    public void run(){
        try
        {
            int ritardo=Game.getRandomInteger(50000,200);
            sleep(ritardo);
        }
        catch (InterruptedException ie)
        {
            ie.printStackTrace();
        }
        attivo=true;
        System.out.println("aereo x: "+x);
        while(attivo){
            try
            {
                if(x==0)
                    attivo=false;
                x-=10;
                sleep(50);
            }
            catch (InterruptedException ie)
            {
                ie.printStackTrace();
            }
        }
    }
    
    /*public void aggiorna(int x){
        this.x=x-100;
    }*/
    
    public void disegna(Graphics g){
        if(attivo)
            g.drawImage(img_aereo,x,y,larghezza,altezza,null);
    }
}
