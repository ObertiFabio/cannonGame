import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.File;

public class CaricatoreImmagini
{
    BufferedImage image;
    
    public BufferedImage caricaImmagine(String posizione) {
        try
        {
            image=ImageIO.read(new File(posizione));
        }
        catch (java.io.IOException ioe)
        {
            System.out.println("immagine alla "+posizione+" trovata");
            ioe.printStackTrace();
        }
        return image;
    }
    
}
