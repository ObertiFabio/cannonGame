
import java.awt.image.BufferedImage;
import java.awt.Graphics;

public class Bomba extends Thread
{
    //attributi cannone
    private int larghezza;
    private int altezza;
    private boolean attivo;
    private int x;
    private int y;
    BufferedImage img_bomba;
    
    //costruttore
    public Bomba(BufferedImage image,int larghezza,int altezza,int x, int y){
        this.larghezza=larghezza;
        this.altezza=altezza;
        this.x=x;
        this.y=y;
        img_bomba=image;
        attivo=false;
    }
    
    public void run(){
        attivo=true;
        System.out.println("bomba x: "+x);
        while(attivo){
            try
            {
                if(y<-300)
                    attivo=false;
                y-=10;
                sleep(25);
            }
            catch (InterruptedException ie)
            {
                ie.printStackTrace();
            }
        }
    }
    
    public void aggiorna(int x){
        this.x=x-100;
    }
    
    public void disegna(Graphics g){
        if(attivo)
            g.drawImage(img_bomba,x,y,larghezza,altezza,null);
    }
}
